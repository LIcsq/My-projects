#!/bin/bash\necho 'This is script3'
