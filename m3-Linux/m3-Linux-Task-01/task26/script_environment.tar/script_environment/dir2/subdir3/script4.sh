#!/bin/bash\necho 'This is script4'
