#!/bin/bash\necho 'This is script2'
