#!/bin/bash\necho 'This is script1'
